public class G extends null {

    void aa();

    int cc();

    public int af() {
        return -1;
    }
}
