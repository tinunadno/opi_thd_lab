public class J extends null {

    long dd();

    void ab();

    public byte oo() {
        return 4;
    }
}
