public class J extends null {

    long dd();

    void ab();

    public int af() {
        return -1;
    }

    public void aa() {
        System.out.println("void aa");
    }

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }
}
