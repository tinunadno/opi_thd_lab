public class C extends null {

    double ad();

    float ff();
}
