public class G extends null {

    void aa();

    int cc();

    public double ad() {
        return 11;
    }

    public Object pp() {
        return this;
    }
}
