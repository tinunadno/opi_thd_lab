public class J extends null {

    long dd();

    void ab();

    public void aa() {
        System.out.println("void aa");
    }

    public Object pp() {
        return this;
    }
}
