public class C extends null {

    double ad();

    float ff();

    public long ac() {
        return 111;
    }

    public Object pp() {
        return this;
    }
}
