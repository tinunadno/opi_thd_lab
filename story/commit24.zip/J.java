public interface J {

    long dd();

    void ab();
}
