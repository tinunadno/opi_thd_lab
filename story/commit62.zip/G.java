public class G extends null {

    void aa();

    int cc();

    public double ad() {
        return 11;
    }

    public Object pp() {
        return this;
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }

    public Object rr() {
        return null;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }

    public int ae() {
        return 9;
    }

    public String kk() {
        return "No";
    }
}
