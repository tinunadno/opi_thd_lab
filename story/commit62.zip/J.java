public class J extends null {

    long dd();

    void ab();

    public void aa() {
        System.out.println("void aa");
    }

    public Object pp() {
        return this;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }

    public int af() {
        return -1;
    }

    public long ac() {
        return 111;
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public double ad() {
        return 12.12;
    }
}
