public interface G {

    void aa();

    int cc();
}
