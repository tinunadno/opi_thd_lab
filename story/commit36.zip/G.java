public class G extends null {

    void aa();

    int cc();

    public int hh() {
        return new java.util.Random().nextInt();
    }
}
