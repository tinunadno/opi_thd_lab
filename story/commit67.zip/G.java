public class G extends null {

    void aa();

    int cc();

    public String kk() {
        return "No";
    }
}
