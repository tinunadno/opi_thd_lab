public class C extends null {

    double ad();

    float ff();

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }
}
