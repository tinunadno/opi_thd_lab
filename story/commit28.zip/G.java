public class G extends null {

    void aa();

    int cc();
}
