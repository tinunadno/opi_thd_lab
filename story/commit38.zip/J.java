public class J extends null {

    long dd();

    void ab();

    public int af() {
        return -1;
    }

    public void aa() {
        System.out.println("void aa");
    }
}
