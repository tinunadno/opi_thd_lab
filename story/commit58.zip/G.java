public class G extends null {

    void aa();

    int cc();

    public double ad() {
        return 11;
    }

    public Object pp() {
        return this;
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }

    public Object rr() {
        return null;
    }
}
