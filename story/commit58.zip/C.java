public class C extends null {

    double ad();

    float ff();

    public long ac() {
        return 111;
    }

    public Object pp() {
        return this;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }
}
