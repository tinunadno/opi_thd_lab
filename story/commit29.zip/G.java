public class G extends null {

    void aa();

    int cc();

    public int ae() {
        return java.lang.Math.abs(-6);
    }
}
