public interface C {

    double ad();

    float ff();
}
