public class B extends null implements C, G, J {

    private String d = "init";

    private long c = 1234;

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }

    public double ad() {
        return java.lang.Math.sqrt(13);
    }

    public float ff() {
        return 0;
    }

    public void aa() {
        return;
    }

    public int cc() {
        return 42;
    }

    public long dd() {
        return 100500;
    }

    public void ab() {
        System.out.println();
    }

    public String kk() {
        return "No";
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }

    public Object pp() {
        return this;
    }

    public Object rr() {
        return null;
    }
}
