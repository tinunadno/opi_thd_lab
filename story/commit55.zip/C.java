public class C extends null {

    double ad();

    float ff();

    public int ae() {
        return java.lang.Math.abs(-6);
    }

    public long ac() {
        return 333;
    }
}
