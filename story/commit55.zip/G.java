public class G extends null {

    void aa();

    int cc();

    public int af() {
        return -1;
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }
}
