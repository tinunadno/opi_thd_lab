public class C extends null {

    double ad();

    float ff();

    public Object rr() {
        return null;
    }

    public long ac() {
        return 111;
    }
}
