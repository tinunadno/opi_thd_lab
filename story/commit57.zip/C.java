public class C extends null {

    double ad();

    float ff();

    public void bb() {
        System.out.println(getClass().getName());
    }

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public String nn() {
        "".>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.;
    }
}
